<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Result</title>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="view_result.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="container mt-5">
        <table class="table-bordered"><tbody>
    <tr>
      <td data-label="Account">Name</td>
      <td data-label="Due Date">Roll no</td>
      <td data-label="Amount">Standard</td>
    </tr> 
    <tr>
      <td data-label="Account">Student_id</td>
      <td data-label="Due Date">Date of Birth</td>
      <td data-label="Amount"><a title="print screen" alt="print screen" onclick="window.print(); "target=_blank" style="cursor:pointer;"><i class="fa-solid fa-print"></i></td>
    </tr> 
</tbody>
</table>
</div>
    <div class="container">
<table class="cap table-bordered">
  <!-- <caption>Statement Summary</caption> -->
  <thead>
    <tr>
      <th scope="col">Subjects</th>
      <th scope="col">Max.Marks</th>
      <th scope="col">Obtained Marks</th>
      <th scope="col">Grade Chart</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td data-label="Account">Telugu</td>
      <td data-label="Due Date">100</td>
      <td data-label="Amount">$1,190</td>
      <td data-label="Period">03/01/2016 - 03/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Account">Hindi-Marathi</td>
      <td data-label="Due Date">100</td>
      <td data-label="Amount">$2,443</td>
      <td data-label="Period">02/01/2016 - 02/29/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Account">English</td>
      <td data-label="Due Date">100</td>
      <td data-label="Amount">$1,181</td>
      <td data-label="Period">02/01/2016 - 02/29/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Mathematics</td>
      <td data-label="Due Date">100</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>   <tr>
      <td scope="row" data-label="Acount">Science&Tech</td>
      <td data-label="Due Date">100</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Social Science</td>
      <td data-label="Due Date">100</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Phy.Education</td>
      <td data-label="Due Date">50</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Personality.Dev</td>
      <td data-label="Due Date">50</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Work Experience</td>
      <td data-label="Due Date">Grade</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Social Service</td>
      <td data-label="Due Date">Grade</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Total</td>
      <td data-label="Due Date">750</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Percentage</td>
      <td data-label="Due Date">%</td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Grade</td>
      <td data-label="Due Date"></td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    <tr>
      <td scope="row" data-label="Acount">Remark</td>
      <td data-label="Due Date"></td>
      <td data-label="Amount">$842</td>
      <td data-label="Period">01/01/2016 - 01/31/2016</td>
    </tr>
    



  </tbody>
</table>
</div>
</body>
</html>