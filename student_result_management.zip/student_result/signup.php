<?php
include 'conn.php';
$showAlert=false;
$showError=false;

if($_SERVER["REQUEST_METHOD"]=="POST"){
if(isset($_POST['user']) || isset($_POST['password'])){
  $username=$_POST['user'];
  $password=$_POST['password'];
  $cpassword=$_POST['cpassword'];

  //$exists=false;
  $existSql="Select * from `signup` where username='$username'";
  $result= mysqli_query($con,$existSql);
  $numRows=mysqli_num_rows($result);
  if($numRows>0){
   // $exists=true;
   $showError=" username already exists";
  }else{
    $exists=false;
  if(($password==$cpassword)){
    $hash=password_hash($password,PASSWORD_DEFAULT);
    $query="insert into signup (username,password,dt) values ('$username','$hash', current_timestamp())";
   $result= mysqli_query($con,$query);
    if($result){
      $showAlert=true;
    }
  }
  else{
    $showError="password do not match";
  }
  }
  }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup form</title>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  <a class="navbar-brand" href="#"><img src="assets\logo-removebg-preview.png" style="width:100px"></a>    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active me-4 " aria-current="page" href="index.php"><i class="fa-solid fa-house-user mx-2"></i>Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="search.php"><i class="fa-solid fa-school mx-2"></i>Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="log.php"><i class="fa-solid fa-lock mx-2"></i>Login</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="signup.php">
          <i class="fa-solid fa-lock mx-2"></i> Signup
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<?php
if($showAlert){
echo '<div class="alert alert-success" role="alert">
Success! your account is created!
</div>';}
if($showError){
  echo '<div class="alert alert-danger" role="alert">
  Error! '. $showError . ';
  </div>';}
  
?>
<div class="text-center mt-5">
  <h1>Sign Up</h1>
</div>
<div class="container d-flex justify-content-center mt-5">
<form action="signup.php" method="post">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="user">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control w-50%" id="exampleInputPassword1" name="password">
  </div>
  <div class="mb-3 ">
    <label for="cpassword" class="form-label">Confirm Password</label>
    <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Password" required>
    <small>Make sure you have to type same password</small>
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<script src="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\js\bootstrap.min.js"></script>

</body>
</html>