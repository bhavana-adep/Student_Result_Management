<?php
 session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  header("location:log.php");
   exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome - <?php echo $_SESSION['username']?></title>
    <link rel="stylesheet" href="admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  <a class="navbar-brand" href="#"><img src="assets\logo-removebg-preview.png" style="width:100px"></a>    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active me-4 " aria-current="page" href="add_new_student.php">Add New Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="insert_marks.php">Insert New Result</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="registered_student.php">Registered Student</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="signup.php">
         Results
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="logout.php">
          Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-5 con" >
<div class="card" style="width: 48rem; height:30rem">
  <img class="card-img-top" >
  <h1 style="margin-top:40px">Welcome</h1>

  <div class="card-body">
    <h3 class="card-text"><?php echo $_SESSION['username']?> </h3>
  </div>
</div>
</div>
<script src="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\js\bootstrap.min.js"></script>
</body>
</html>