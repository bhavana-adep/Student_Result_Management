<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome - <?php echo $_SESSION['username']?></title>
    <link rel="stylesheet" href="admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  <a class="navbar-brand" href="#"><img src="assets\logo-removebg-preview.png" style="width:100px"></a>    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active me-4 " aria-current="page" href="add_new_student.php">Add New Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="insert_marks.php">Insert New Result</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="registered_student.php">Registered Student</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="signup.php">
         Results
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="logout.php">
          Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<main>
        
        <!--MDB Tables-->
        <div class="container mt-4">
            <div class="card mb-4">
                <div class="card-body">
                    <!--Table-->
                    

                    
                    <table class="table table-hover">
                        <!--Table head-->
                        <thead class="mdb-color bg-primary">
                            <tr class="text-white">
                                <th>id</th>
                                <th>Name</th>
                                <th>ROll No</th>
                                <th>Class</th>
                                <th>Student_id</th>
                                <th>Gender</th>
                                <th>Mobile No</th>
                                <th>State</th>
                                <th>Date of Birth</th>
                            </tr>
                        </thead>
                        <!--Table head-->
                        <!--Table body-->
                        <tbody>
                        <?php

include 'conn.php';

session_start();
if(isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  
}
$user2=$_SESSION["username"];
$con=mysqli_connect('localhost','root','','student_result');
$myquery="select * from signup where username='$user2'";
$query2=mysqli_query($con,$myquery);
$row2=mysqli_fetch_array($query2);
$id=$row2["id"];
$query4=mysqli_query($con,"select * from registration where user_id=$id");
$rowcount=mysqli_num_rows($query4);


for($i=1;$i<=$rowcount;$i++){
    
    $resp=mysqli_fetch_array($query4);
    ?>
    <tr>

    <td><?php echo $resp['id']; ?></td>
    <td><?php echo $resp['name']; ?></td>
    <td><?php echo $resp['roll_no']; ?></td>
    <td><?php echo $resp['class']; ?></td>
    <td><?php echo $resp['student_id']; ?></td>
    <td><?php echo $resp['gender']; ?></td>
    <td><?php echo $resp['mobile_no']; ?></td>
    <td><?php echo $resp['state']; ?></td>
    <td><?php echo $resp['d_of_birth']; ?></td>
</tr>
<?php
}
?>
                           
                        </tbody>
                        <!--Table body-->
                    </table>
                    <!--Table-->
                </div>
            </div>

        </div>
        <!--MDB Tables-->
      
    </main>
  
<script src="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\js\bootstrap.min.js"></script>
</body>
</html>