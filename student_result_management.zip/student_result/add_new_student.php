<?php
include 'conn.php';


session_start();
if(isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  
}
if(isset($_POST['fname'])||isset($_POST['rno'])||isset($_POST['class'])||isset($_POST['std'])||isset($_POST['gender'])||isset($_POST['phone'])||isset($_POST['state'])||isset($_POST['dob'])){
$user2=$_SESSION["username"];
$con=mysqli_connect('localhost','root','','student_result');
$myquery="select * from signup where username='$user2'";
$query2=mysqli_query($con,$myquery);
$row2=mysqli_fetch_array($query2);
$id=$row2["id"];

$fullname=$_POST['fname'];
$rollno=$_POST['rno'];
$cls=$_POST['class'];
$studentid=$_POST['std'];
$identity=$_POST['gender'];
$mobile=$_POST['phone'];
$state=$_POST['state'];
$birth=$_POST['dob'];


$insertquery="INSERT INTO `registration`(`name`, `roll_no`, `class`, `student_id`, `gender`, `mobile_no`, `state`, `d_of_birth`,`user_id`) VALUES ('$fullname','$rollno','$cls','$studentid','$identity','$mobile','$state','$birth','$id')";

mysqli_query($con,$insertquery);

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome - <?php echo $_SESSION['username']?></title>
    <link rel="stylesheet" href="new_student.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  <a class="navbar-brand" href="#"><img src="assets\logo-removebg-preview.png" style="width:100px"></a>    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active me-4 " aria-current="page" href="add_new_student.php">Add New Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="insert_marks.php">Insert New Result</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="registered_student.php">Registered Student</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="signup.php">
         Results
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="logout.php">
          Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-5">
  <form action="add_new_student.php" method="POST">
    <div class="row jumbotron box8">
      <div class="col-sm-12 mx-t3 mb-4 mt-3">
        <h2 class="text-center text-info">Register</h2>
      </div>
      <div class="col-sm-6 form-group">
        <label for="name-f">Full Name</label>
        <input type="text" class="form-control mt-2" name="fname" id="name-f" placeholder="Enter your full name." required>
      </div>
      <div class="col-sm-6 form-group">
        <label for="name-l">Roll No</label>
        <input type="number" class="form-control mt-2" name="rno" id="name-l" placeholder="Enter your roll no." required>
      </div>
      <div class="col-sm-6 form-group mt-3">
        <label for="tel">Phone</label>
        <input type="tel" name="phone" class="form-control mt-2" id="tel" placeholder="Enter Your Contact Number." pattern="[0-9]{10}" required>
      </div>
      <div class="col-sm-6 form-group mt-3">
        <label for="address-1">Class</label>
        <input type="address" class="form-control mt-2" name="class" id="address-1" placeholder="enter your class." required>
      </div>
      <div class="col-sm-6 form-group mt-3">
        <label for="address-2">Student Id</label>
        <input type="number" class="form-control mt-2" name="std" id="address-2" placeholder="enter your student id." required>
      </div>
      <div class="col-sm-6 form-group mt-3">
        <label for="State">State</label>
        <input type="text" class="form-control mt-2" name="state" id="State" placeholder="Enter your state name." required>
      </div>
      <div class="col-sm-6 form-group mt-3">
        <label for="Date">Date Of Birth</label>
        <input type="Date" name="dob" class="form-control mt-2" id="Date" placeholder="" required>
      </div>
      <div class="col-sm-6 form-group mt-3">
        <label for="sex">Gender</label>
        <input type="text" name="gender" class="form-control mt-2" id="sex" placeholder="enter your gender" required>
      </div>
      <div class="col-sm-6 mt-3">
        <input type="checkbox" class="form-check d-inline" id="chb" required><label for="chb" class="form-check-label">&nbsp;I accept all terms and conditions.
        </label>
      </div>

      <div class="col-sm-12 form-group mb-0 mt-3">
        <button class="btn btn-primary float-end">Submit</button>
      </div>

    </div>
  </form>
</div>
<script src="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\js\bootstrap.min.js"></script>

</body>
</html>