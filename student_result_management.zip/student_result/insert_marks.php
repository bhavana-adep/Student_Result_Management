<?php
include 'conn.php';


session_start();
if(isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  
}
// if(isset($a)||isset($b)||isset($c)||isset($d)||isset($e)||isset($f)||isset($g)||isset($h)||isset($i)||isset($j)||isset($k)||isset($l)){
if(isset($_POST['result'])){
$user3=$_SESSION["username"];
$con=mysqli_connect('localhost','root','','student_result');
$myquery="select * from signup where username='$user3'";
$query2=mysqli_query($con,$myquery);
$row3=mysqli_fetch_array($query2);
$id=$row3["id"];
$a=$_POST['fname'];
$b=$_POST['year'];
$c=$_POST['tel'];
$d=$_POST['hindi'];
$e=$_POST['eng'];
$f=$_POST['math'];
$g=$_POST['tech'];
$h=$_POST['social'];
$i=$_POST['edu'];
$j=$_POST['person'];
$k=$_POST['work'];
$l=$_POST['serv'];
$to=$d+$e+$f+$g+$h+$i+$j;
$per=($to/750)*100;
if($per>75)
{
  $gr='A';
}
else if($per>60 && $per<=74)
{
  $gr='B';
}
else if($per>50 && $per<=59)
{
  $gr='C';
}
else if($per>35 && $per<=49)
{
  $gr='D';
}
else
{
  $gr='fail';
}
if($a>35 && $b>35 && $c>35 && $d>35 && $e>35 && $f>35 && $g>35 && $h>35 && $i>35 && $j>35)
{
  $rem='Passed';
}
else{
  $rem="Failed";
}
$resquery="INSERT INTO `result`( `name`, `year`, `telugu`, `hin-mar`, `eng`, `math`, `sci`, `soc`, `phy`, `pers`, `work`, `serv`, `total`, `per`, `gra`, `rem`, `user_id`) VALUES ('[$a]','[$b]','[$c]','[$d]','[$e]','[$f]','[$g]','[$h]','[$i]','[$j]','[$k]','[$l]','[$to]','[$per]','[$gr]','[$rem]','[$id]')";
mysqli_query($con,$resquery);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome - <?php echo $_SESSION['username']?></title>
    <link rel="stylesheet" href="new_student.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  <a class="navbar-brand" href="#"><img src="assets\logo-removebg-preview.png" style="width:100px"></a>    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active me-4 " aria-current="page" href="add_new_student.php">Add New Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="insert_marks.php">Insert New Result</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="registered_student.php">Registered Student</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="signup.php">
         Results
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="logout.php">
          Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-5">
  <form action="insert_marks.php" method="POST">
    <div class="row jumbotron box8">
      <div class="col-sm-12 mx-t3 mb-4 mt-3">
        <h2 class="text-center text-info">Marks</h2>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="name-f">Full Name</label>
        <input type="text" class="form-control mt-2" name="fname" id="name-f" placeholder="Enter your full name." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="name-l">Year of Passing</label>
        <input type="number" class="form-control mt-2" name="year" id="name-l" placeholder="Enter Your Year." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="tel">Telugu</label>
        <input type="number" name="tel" class="form-control mt-2" id="tel" placeholder="Enter Marks." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="address-1">Hindi-Marathi</label>
        <input type="number" class="form-control mt-2" name="hindi" id="address-1" placeholder="Enter Marks." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="address-2">English</label>
        <input type="number" class="form-control mt-2" name="eng" id="address-2" placeholder="Enter Marks." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="State">Mathematics</label>
        <input type="number" class="form-control mt-2" name="math" id="State" placeholder="Enter Marks." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="Date">Science&Tech.</label>
        <input type="number" name="tech" class="form-control mt-2" id="Date" placeholder="Enter Marks" required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="sex">Social Science</label>
        <input type="number" name="social" class="form-control mt-2" id="sex" placeholder="Enter Marks" required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="name-f">Phy.Education</label>
        <input type="text" class="form-control mt-2" name="edu" id="name-f" placeholder="Enter Marks." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="name-f">Personalty.Dev.</label>
        <input type="text" class="form-control mt-2" name="person" id="name-f" placeholder="Enter Marks." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="name-f">Work Experience</label>
        <input type="text" class="form-control mt-2" name="work" id="name-f" placeholder="Enter Grade." required>
      </div>
      <div class="col-sm-4 form-group mt-3">
        <label for="name-f">Social Service</label>
        <input type="text" class="form-control mt-2" name="serv" id="name-f" placeholder="Enter Grade." required>
      </div>
    
    


      <div class="col-sm-12 form-group mb-0 mt-3">
        <button class="btn btn-primary float-end" name="result">Submit</button>
      </div>

    </div>
  </form>
</div>
<script src="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\js\bootstrap.min.js"></script>
</body>
</html>