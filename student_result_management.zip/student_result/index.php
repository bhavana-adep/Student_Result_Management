<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  <a class="navbar-brand" href="#"><img src="assets\logo-removebg-preview.png" style="width:100px"></a>    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active me-4 " aria-current="page" href="index.php"><i class="fa-solid fa-house-user mx-2"></i>Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="search.php"><i class="fa-solid fa-school mx-2"></i>Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="log.php"><i class="fa-solid fa-lock mx-2"></i>Login</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="signup.php">
          <i class="fa-solid fa-lock mx-2"></i> Signup
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container">
<div id="carouselExampleControls" class="carousel slide mt-5" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="assets\slide1.jpg" class="d-block w-100 h-60%" alt="...">
    </div>
    <div class="carousel-item">
      <img src="assets\slide2.jpg" class="d-block w-100 h-6%" alt="...">
    </div>
    <div class="carousel-item">
      <img src="assets\slide3.jpg" class="d-block w-100 h-60%" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<script src="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\js\bootstrap.min.js"></script>
</body>
</html>