<?php
include 'conn.php';
$login=false;
$showError=false;
if($_SERVER["REQUEST_METHOD"]=="POST"){
if(isset($_POST['username']) || isset($_POST['password'])){
    $username1=$_POST['username'];
    $password1=$_POST['password'];
    $myquery="Select * from signup where username='$username1'";
    $result= mysqli_query($con,$myquery);
    $num=mysqli_num_rows($result);
    if($num==1){
        while($row=mysqli_fetch_assoc($result)){
            if(password_verify($password1,$row['password'])){
                $login=true;
                session_start();
        $_SESSION['loggedin']=true;
        $_SESSION['username']=$username1;
        header("location:admin.php");
            }
            else{
                $showError="Invalid crendtials";
              }
        }
      
        
      }
      else{
        $showError="Invalid crendtials";
      }
}
}
    ?>
   
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  <a class="navbar-brand" href="#"><img src="assets\logo-removebg-preview.png" style="width:100px"></a>    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active me-4 " aria-current="page" href="index.php"><i class="fa-solid fa-house-user mx-2"></i>Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="search.php"><i class="fa-solid fa-school mx-2"></i>Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-4" href="log.php"><i class="fa-solid fa-lock mx-2"></i>Login</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link me-4" href="signup.php">
          <i class="fa-solid fa-lock mx-2"></i> Signup
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<?php
if($login){
echo '<div class="alert alert-success" role="alert">
Success! your are logged in!
</div>';}
if($showError){
  echo '<div class="alert alert-danger" role="alert">
  Error! '. $showError . ';
  </div>';}
  
?>
<div class="text-center mt-5">
  <h1>Login</h1>
</div>
<div class="container d-flex justify-content-center mt-5">
<form action="log.php" method="post">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="username">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control w-50%" id="exampleInputPassword1" name="password">
  </div>
 

  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<script src="bootstrap-5.0.2-dist\bootstrap-5.0.2-dist\js\bootstrap.min.js"></script>
</body>
</html>