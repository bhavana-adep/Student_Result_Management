<?php
//error_reporting(0);
$username="root";
$password="";
$server='localhost';
$db='student_result';

$con=mysqli_connect($server,$username,$password,$db);

if($con){
  echo "connection successful";
}
  else{
die ("no connection" . mysqli_connect_error());
  } 

  
// if(isset($fullname)||isset($rollno)||isset($cls)||isset($studentid)||isset($identity)||isset($mobile)||isset($state)||isset($birth)){
//   $fullname=$_POST['fname'];
//      $rollno=$_POST['rno'];
//      $cls=$_POST['class'];
//      $studentid=$_POST['std'];
//      $identity=$_POST['gender'];
//      $mobile=$_POST['phone'];
//      $state=$_POST['state'];
//      $birth=$_POST['dob'];
 

// $insertquery="INSERT INTO `registration`(`name`, `roll_no`, `class`, `student_id`, `gender`, `mobile_no`, `state`, `d_of_birth`,`user_id`) VALUES ('$fullname','$rollno','$cls','$studentid','$identity','$mobile','$state','$birth','$id')";

// mysqli_query($con,$insertquery);


  ?>